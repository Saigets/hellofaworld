.. super_unique_anchor::
###############
Developer guide
###############

asdf
.. contents::
   :local:

*******************
Ansible style guide
*******************
sdfsdf
jj
.. table:: File descriptions

  +----------+----------------------------+
  |File      |Purpose                     |
  +==========+============================+
  |foo.txt   |foo configuration settings  |
  +----------+----------------------------+
  |bar.txt   |bar configuration settings  |
  +----------+----------------------------+


Mechanical guidelines
=====================
asdfasdf

:ref:`super_unique_anchor`
:ref:`this page super_unique_anchor`

Internal navigation
-------------------
asdfsdfs 

Adding anchors
^^^^^^^^^^^^^^

sdfsdf
:ref:`super_unique_anchor`
:ref:`this page super_unique_anchor`

Paragraph that needs a title
""""""""""""""""""""""""""""
dfgdfg
df
gdf

:ref:`arista.eos.eos_config <ansible_collections.arista.eos.eos_config_module>`
:ref:`kubernetes.core.kubectl connection plugin <ansible_collections.kubernetes.core.kubectl_connection>`

.. code-block:: python

   def my_beautiful_python_code():
      pass

